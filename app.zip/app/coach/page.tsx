'use client';
export const dynamic = 'force-dynamic';

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { getSupabase } from "../lib/supabase";
import { normalizePlanTier, tierDefinition, tierTone, type PlanTier } from "../lib/productTiers";
import {
  confidenceLabel,
  pct,
  sortWeakest,
  pickWeakestAcrossSubjects,
  stableRows,
  lowSignalRows,
  type SkillRow as SharedSkillRow,
} from "../lib/learningSignals";
import { useStudentState } from "../lib/useStudentState";
import { ActionDock, Card, LoopRail, PageHeader, Pill, PrimaryButton, SecondaryButton, StatBox } from "../ui/ui";

type Profile = {
  id: string;
  nickname: string | null;
  target_score: number | null;
  daily_study_hours: number | null;
  exam_date: string | null;
  weakest_area: string | null;
  current_level: string | null;
  plan_tier: string | null;
};

type SkillRow = SharedSkillRow;

type Question = {
  id: string;
};

type LeaderEntry = {
  user_id: string;
  nickname: string;
  answered: number;
  correct: number;
  review_answered: number;
  accuracy: number;
  points: number;
};

function daysUntil(iso: string | null): number | null {
  if (!iso) return null;
  const d = new Date(iso);
  if (isNaN(d.getTime())) return null;

  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const end = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  return Math.round((end - start) / (1000 * 60 * 60 * 24));
}

function coachHeadline(args: {
  dueReviewCount: number;
  weakestOverall: { subject: "Reading" | "Math"; row: SkillRow } | null;
  dleft: number | null;
}) {
  const { dueReviewCount, weakestOverall, dleft } = args;

  if (dueReviewCount > 0) {
    return {
      title: "Your priority is recovery, not more volume.",
      body:
        dueReviewCount === 1
          ? "You have 1 review item due. Clear it before adding more forward work."
          : `You have ${dueReviewCount} review items due. Clear them before adding more forward work.`,
      tone: "accent" as const,
    };
  }

  if (weakestOverall?.row) {
    return {
      title: `Your best opportunity is ${weakestOverall.row.subskill}.`,
      body: `This is the weakest current signal in ${weakestOverall.subject}. Fixing it now should improve your next practice loop more than broad unfocused work.`,
      tone: "accent" as const,
    };
  }

  if (dleft !== null && dleft <= 30 && dleft >= 0) {
    return {
      title: "You need clean signal and disciplined selection.",
      body:
        "Your exam window is close enough that wasted sessions matter. Keep practice tight, recovery honest, and weak-skill work targeted.",
      tone: "danger" as const,
    };
  }

  return {
    title: "Your job is to generate clean signal and act on it.",
    body:
      "You do not need more noise. You need clear weak-zone evidence, targeted repair, and consistent review.",
    tone: "neutral" as const,
  };
}

export default function CoachPage() {
  const router = useRouter();
  const { state: studentState } = useStudentState({ dueLimit: 80, historyLimit: 64 });

  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  const [profile, setProfile] = useState<Profile | null>(null);
  const [skillsReading, setSkillsReading] = useState<SkillRow[]>([]);
  const [skillsMath, setSkillsMath] = useState<SkillRow[]>([]);
  const [dueReviewCount, setDueReviewCount] = useState(0);
  const [leaderboard, setLeaderboard] = useState<LeaderEntry[]>([]);

  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [aiCoach, setAiCoach] = useState<null | {
    coach_note_title: string;
    coach_note_body: string;
    top_issues: { title: string; detail: string }[];
    three_step_plan: { step: "1" | "2" | "3"; title: string; detail: string }[];
    tone_label: "Focused" | "Urgent" | "Rebuild" | "Advance";
  }>(null);

  const nickname = profile?.nickname?.trim() || "Student";
  const planTier = useMemo<PlanTier>(() => normalizePlanTier(profile?.plan_tier ?? "free"), [profile?.plan_tier]);
  const tier = useMemo(() => tierDefinition(planTier), [planTier]);
  const dleft = useMemo(() => daysUntil(profile?.exam_date ?? null), [profile]);

  const weakestOverall = useMemo(() => {
    return pickWeakestAcrossSubjects(skillsReading, skillsMath);
  }, [skillsReading, skillsMath]);

  const stableWeakAreas = useMemo(() => {
    return sortWeakest(stableRows([...skillsReading, ...skillsMath])).slice(0, 3);
  }, [skillsReading, skillsMath]);

  const lowSignalCount = useMemo(() => {
    return lowSignalRows([...skillsReading, ...skillsMath]).length;
  }, [skillsReading, skillsMath]);

  const myLeague = useMemo(() => {
    if (!profile) return null;
    const idx = leaderboard.findIndex((x) => x.user_id === profile.id);
    if (idx === -1) return null;
    return {
      rank: idx + 1,
      points: Math.round(leaderboard[idx].points),
    };
  }, [leaderboard, profile]);

  const activeDueReviewCount = studentState?.reviewDebt.dueCount ?? dueReviewCount;

  const strategistNote = useMemo(() => {
    return coachHeadline({
      dueReviewCount: activeDueReviewCount,
      weakestOverall,
      dleft,
    });
  }, [activeDueReviewCount, weakestOverall, dleft]);

  const nextAction = useMemo(() => {
    if (activeDueReviewCount > 0) {
      return {
        title: "Clear the recovery queue",
        description: "Review is due. Do not stack new questions on top of unresolved mistakes.",
        primaryHref: "/review",
        primaryLabel: "Start review",
        secondaryHref: weakestOverall?.row
          ? `/practice?subject=${weakestOverall.subject}&subskill=${encodeURIComponent(weakestOverall.row.subskill)}`
          : "/today",
        secondaryLabel: weakestOverall?.row ? "Skip to weakest practice" : "Back to Today",
      };
    }

    if (weakestOverall?.row) {
      return {
        title: `Repair ${weakestOverall.row.subskill}`,
        description: `Current weakest zone in ${weakestOverall.subject}: ${pct(
          weakestOverall.row.accuracy
        )}% over ${weakestOverall.row.attempts} attempts.`,
        primaryHref: `/practice?subject=${weakestOverall.subject}&subskill=${encodeURIComponent(
          weakestOverall.row.subskill
        )}`,
        primaryLabel: "Practice weakest",
        secondaryHref: `/lesson/${encodeURIComponent(weakestOverall.row.subskill)}`,
        secondaryLabel: "Open lesson",
      };
    }

    return {
      title: "Generate cleaner evidence",
      description:
        "You do not have enough stable weakness signal yet. One focused set will improve the quality of your recommendations.",
      primaryHref: "/practice?subject=Reading",
      primaryLabel: "Start Reading practice",
      secondaryHref: "/practice?subject=Math",
      secondaryLabel: "Start Math practice",
    };
  }, [activeDueReviewCount, weakestOverall]);

  const effectiveNextAction = useMemo(() => {
    if (!studentState) return nextAction;
    return {
      title: studentState.recommendedAction.title,
      description: `${studentState.recommendedAction.reason} ${studentState.recommendedAction.payoff}`,
      primaryHref: studentState.recommendedAction.primaryHref,
      primaryLabel: studentState.recommendedAction.primaryLabel,
      secondaryHref: studentState.recommendedAction.secondaryHref,
      secondaryLabel: studentState.recommendedAction.secondaryLabel,
    };
  }, [studentState, nextAction]);

  const coachSnapshot = useMemo(() => {
    return {
      nickname,
      examCountdownDays: dleft,
      dueReviewCount: activeDueReviewCount,
      weeklyRank: myLeague?.rank ?? null,
      weeklyPoints: myLeague?.points ?? null,
      stableWeakAreas: stableWeakAreas.map((row) => ({
        subject: skillsReading.includes(row) ? "Reading" as const : "Math" as const,
        subskill: row.subskill,
        domain: row.domain,
        skill: row.skill,
        attempts: row.attempts,
        accuracy: row.accuracy,
      })),
      lowSignalCount,
      nextAction: effectiveNextAction,
    };
  }, [nickname, dleft, activeDueReviewCount, myLeague, stableWeakAreas, lowSignalCount, effectiveNextAction, skillsReading]);

  const threeStepPlan = useMemo(() => {
    if (activeDueReviewCount > 0 && weakestOverall?.row) {
      return [
        {
          step: "1",
          title: "Clear due review",
          text: "Recover active mistakes first so they stop contaminating new work.",
          href: "/review",
          label: "Open review",
        },
        {
          step: "2",
          title: `Target ${weakestOverall.row.subskill}`,
          text: "Immediately follow recovery with narrow repair on the weakest live signal.",
          href: `/practice?subject=${weakestOverall.subject}&subskill=${encodeURIComponent(
            weakestOverall.row.subskill
          )}`,
          label: "Practice weakest",
        },
        {
          step: "3",
          title: "Lock the concept",
          text: "Use the lesson if the weakness is conceptual, not just execution-based.",
          href: `/lesson/${encodeURIComponent(weakestOverall.row.subskill)}`,
          label: "Open lesson",
        },
      ];
    }

    if (weakestOverall?.row) {
      return [
        {
          step: "1",
          title: `Repair ${weakestOverall.row.subskill}`,
          text: "Your weakest live signal deserves first attention.",
          href: `/practice?subject=${weakestOverall.subject}&subskill=${encodeURIComponent(
            weakestOverall.row.subskill
          )}`,
          label: "Practice weakest",
        },
        {
          step: "2",
          title: "Read the repair note",
          text: "If the problem is conceptual, use the lesson before repeating more questions.",
          href: `/lesson/${encodeURIComponent(weakestOverall.row.subskill)}`,
          label: "Open lesson",
        },
        {
          step: "3",
          title: "Re-check the map",
          text: "Return to the skills layer and confirm whether the weak signal improves.",
          href: "/skills",
          label: "Open skills",
        },
      ];
    }

    return [
      {
        step: "1",
        title: "Generate signal",
        text: "You need more evidence before strategy becomes precise.",
        href: "/practice?subject=Reading",
        label: "Start practice",
      },
      {
        step: "2",
        title: "Check recovery later",
        text: "Wrong answers should flow into review instead of being forgotten.",
        href: "/review",
        label: "Open review",
      },
      {
        step: "3",
        title: "Inspect the map",
        text: "Once enough rows stabilize, your next repair route becomes clearer.",
        href: "/skills",
        label: "Open skills",
      },
    ];
  }, [activeDueReviewCount, weakestOverall]);

  async function load() {
    setLoading(true);
    setErr(null);

    try {
      const supabase = getSupabase();

      const { data: sessionData, error: sessErr } = await supabase.auth.getSession();
      if (sessErr) throw new Error(sessErr.message);

      const session = sessionData.session;
      if (!session) {
        router.push("/login");
        return;
      }

      const userId = session.user.id;

      let profileRes = await supabase
        .from("profiles")
        .select("id,nickname,target_score,daily_study_hours,exam_date,weakest_area,current_level,plan_tier")
        .eq("id", userId)
        .single();

      if (
        profileRes.error &&
        String(profileRes.error.message || "").toLowerCase().includes("plan_tier")
      ) {
        profileRes = await supabase
          .from("profiles")
          .select("id,nickname,target_score,daily_study_hours,exam_date,weakest_area,current_level")
          .eq("id", userId)
          .single();
      }

      if (profileRes.error) throw new Error(profileRes.error.message);
      const base = profileRes.data as Omit<Profile, "plan_tier"> & { plan_tier?: string | null };
      setProfile({
        ...base,
        plan_tier: base.plan_tier ?? "free",
      });

      const [readingRes, mathRes, dueRes, lbRes] = await Promise.all([
        supabase.rpc("get_skill_mastery", { p_subject: "Reading" }),
        supabase.rpc("get_skill_mastery", { p_subject: "Math" }),
        supabase.rpc("get_due_review_questions", { p_limit: 50 }),
        supabase.rpc("get_weekly_leaderboard"),
      ]);

      if (readingRes.error) throw new Error(readingRes.error.message);
      if (mathRes.error) throw new Error(mathRes.error.message);
      if (dueRes.error) throw new Error(dueRes.error.message);
      if (lbRes.error) throw new Error(lbRes.error.message);

      setSkillsReading((readingRes.data ?? []) as SkillRow[]);
      setSkillsMath((mathRes.data ?? []) as SkillRow[]);
      setDueReviewCount(((dueRes.data ?? []) as Question[]).length);
      setLeaderboard((lbRes.data ?? []) as LeaderEntry[]);
    } catch (e: unknown) {
      setErr(e instanceof Error ? e.message : "Failed to load coach.");
    } finally {
      setLoading(false);
    }
  }

  async function generateCoachNote() {
    if (aiLoading) return;
    if (!tier.limits.coachAi) {
      setAiError("AI strategist is available on Pro and Ultimate.");
      return;
    }
    setAiLoading(true);
    setAiError(null);
    try {
      const supabase = getSupabase();
      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (!session?.access_token) {
        throw new Error("You need to sign in.");
      }

      const res = await fetch("/api/coach", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${session.access_token}`,
        },
        body: JSON.stringify(coachSnapshot),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data?.error || "Failed to generate coach note.");
      }
      setAiCoach(data);
    } catch (e: unknown) {
      setAiError(e instanceof Error ? e.message : "Failed to generate coach note.");
    } finally {
      setAiLoading(false);
    }
  }

  useEffect(() => {
    let cancelled = false;

    const run = async () => {
      await Promise.resolve();
      if (!cancelled) await load();
    };

    void run();

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <main className="min-h-screen">
      <PageHeader
        label="Strategist layer"
        title="Coach"
        subtitle={`Personal analysis for ${nickname}. Understand what matters now.`}
        right={
          <div className="flex items-center gap-2">
            <Pill text={`${tier.label} plan`} tone={tierTone(planTier)} />
            <Pill text="Strategist" tone="accent" />
          </div>
        }
      />

      {loading && (
        <Card title="Loading…" subtitle="Building your strategist view">
          <div className="text-sm text-gray-600">Please wait.</div>
        </Card>
      )}

      {!loading && err && (
        <Card title="Error" subtitle="Coach could not load">
          <div className="text-sm text-red-600">{err}</div>
          <div className="mt-4 grid gap-3">
            <PrimaryButton onClick={load}>Try again</PrimaryButton>
            <SecondaryButton href="/today">Back to Today</SecondaryButton>
          </div>
        </Card>
      )}

      {!loading && !err && (
        <div className="grid gap-5">
          <LoopRail
            active="Coach"
            next={activeDueReviewCount > 0 ? "Review" : weakestOverall?.row ? "Practice" : "Practice"}
            note="Coach should interpret the loop, not replace it."
          />

          <section className="ink-surface overflow-hidden rounded-[30px] border border-[#213258] bg-[linear-gradient(145deg,#0f172a,#111827_46%,#0b1222)] shadow-xl">
            <div className="grid gap-5 p-5 sm:p-6 lg:grid-cols-[1.2fr_0.8fr]">
              <div>
                <div className="inline-flex items-center rounded-full border border-[#3f5fa1] bg-white/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-[#bdd5ff]">
                  Strategist command
                </div>
                <h2 className="mt-3 text-3xl font-semibold tracking-tight text-white">{effectiveNextAction.title}</h2>
                <p className="mt-2 text-sm leading-relaxed text-[#d2dbec]">
                  {effectiveNextAction.description}
                </p>
                <div className="mt-5 grid gap-3 sm:max-w-xl sm:grid-cols-2">
                  <Link
                    href={effectiveNextAction.primaryHref}
                    className="inline-flex items-center justify-center rounded-xl bg-white px-4 py-3 text-sm font-semibold text-[#0f1b33] transition hover:bg-[#ecf3ff]"
                  >
                    {effectiveNextAction.primaryLabel}
                  </Link>
                  <Link
                    href={effectiveNextAction.secondaryHref}
                    className="inline-flex items-center justify-center rounded-xl border border-[#506894] bg-white/5 px-4 py-3 text-sm font-semibold text-[#d7e3fb] transition hover:border-[#6f8ec7] hover:bg-white/10"
                  >
                    {effectiveNextAction.secondaryLabel}
                  </Link>
                </div>
              </div>

              <div className="grid gap-3">
                <div className="rounded-2xl border border-white/15 bg-white/5 p-4">
                  <div className="text-xs font-semibold uppercase tracking-[0.12em] text-[#a6c5ff]">Due review</div>
                  <div className="mt-1 text-3xl font-semibold tracking-tight text-white">{activeDueReviewCount}</div>
                  <div className="mt-1 text-xs text-[#c5d1e8]">Immediate recovery load</div>
                </div>
                <div className="rounded-2xl border border-white/15 bg-white/5 p-4">
                  <div className="text-xs font-semibold uppercase tracking-[0.12em] text-[#a6c5ff]">Stable weak areas</div>
                  <div className="mt-1 text-3xl font-semibold tracking-tight text-white">{stableWeakAreas.length}</div>
                  <div className="mt-1 text-xs text-[#c5d1e8]">High-confidence weak signals</div>
                </div>
                <div className="rounded-2xl border border-white/15 bg-white/5 p-4">
                  <div className="text-xs font-semibold uppercase tracking-[0.12em] text-[#a6c5ff]">AI window</div>
                  <div className="mt-1 text-2xl font-semibold tracking-tight text-white">
                    {tier.limits.coachAi ? `${tier.limits.coachRateLimitPer10Min}/10m` : "Locked"}
                  </div>
                  <div className="mt-1 text-xs text-[#c5d1e8]">{tier.label} plan</div>
                </div>
              </div>
            </div>
          </section>

          {studentState && (
            <Card title="Live guide layer" subtitle="Contextual nudges pulled from the same student state used across the app." right={<Pill text="Deterministic" tone="accent" />}>
              <div className="grid gap-2 sm:grid-cols-2">
                {studentState.contextualMessages.coach.slice(0, 4).map((message) => (
                  <div key={message.id} className="rounded-xl border border-gray-200 bg-gray-50 px-3 py-3 text-sm text-gray-700">
                    {message.text}
                    {message.actionHref && message.actionLabel && (
                      <div className="mt-2">
                        <Link href={message.actionHref} className="text-xs font-semibold text-[#004aad] underline">
                          {message.actionLabel}
                        </Link>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </Card>
          )}

          <Card
            title="Strategist note"
            subtitle="Personalized interpretation of your current training state."
            right={
              <Pill
                text={
                  aiCoach?.tone_label ??
                  (strategistNote.tone === "danger" ? "Urgent" : "Focused")
                }
                tone={
                  aiCoach?.tone_label === "Urgent"
                    ? "danger"
                    : aiCoach?.tone_label === "Rebuild"
                    ? "danger"
                    : "accent"
                }
              />
            }
            accent
          >
            <div className="rounded-2xl border border-[#c7dbff] bg-[#f6faff] p-5">
              <div className="text-xs font-semibold uppercase tracking-[0.12em] text-[#004aad]">
                Personal strategist
              </div>
              {aiLoading ? (
                <div className="mt-3 text-sm text-gray-600">Generating strategist note…</div>
              ) : aiError ? (
                <div className="mt-3 text-sm text-red-600">{aiError}</div>
              ) : aiCoach ? (
                <>
                  <div className="mt-2 text-2xl font-semibold tracking-tight text-black">
                    {aiCoach.coach_note_title}
                  </div>
                  <div className="mt-3 max-w-3xl text-sm leading-relaxed text-gray-700">
                    {aiCoach.coach_note_body}
                  </div>
                </>
              ) : (
                <>
                  <div className="mt-2 text-2xl font-semibold tracking-tight text-black">
                    {strategistNote.title}
                  </div>
                  <div className="mt-3 max-w-3xl text-sm leading-relaxed text-gray-700">
                    {strategistNote.body}
                  </div>
                </>
              )}

              <div className="mt-5 flex flex-wrap gap-3">
                {tier.limits.coachAi ? (
                  <>
                    <button
                      onClick={generateCoachNote}
                      disabled={aiLoading}
                      className="inline-flex items-center justify-center rounded-xl bg-[#004aad] px-4 py-3 text-sm font-semibold text-white transition hover:bg-[#003b88] disabled:opacity-60"
                    >
                      {aiLoading
                        ? "Generating strategist note..."
                        : aiCoach
                        ? "Refresh strategist note"
                        : "Generate strategist note"}
                    </button>
                    <div className="flex items-center text-xs text-gray-500">
                      AI analysis is optional and may take 5-15 seconds.
                    </div>
                  </>
                ) : (
                  <>
                    <Link
                      href="/pricing"
                      className="inline-flex items-center justify-center rounded-xl bg-[#004aad] px-4 py-3 text-sm font-semibold text-white transition hover:bg-[#003b88]"
                    >
                      Unlock AI strategist
                    </Link>
                    <div className="flex items-center text-xs text-gray-500">
                      Pro and Ultimate unlock strategist generation.
                    </div>
                  </>
                )}
              </div>
            </div>
          </Card>

          {aiCoach && (
            <Card
              title="Top issues"
              subtitle="What is most likely holding performance back right now."
              right={<Pill text="AI interpretation" tone="accent" />}
            >
              <div className="grid gap-3">
                {aiCoach.top_issues.map((issue, i) => (
                  <div key={i} className="rounded-xl border border-gray-200 p-4">
                    <div className="font-semibold text-black">{issue.title}</div>
                    <div className="mt-2 text-sm leading-relaxed text-gray-700">
                      {issue.detail}
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}

          <div className="grid gap-4 lg:grid-cols-[1.1fr_0.9fr]">
            <Card
              title="Best next action"
              subtitle="Do this before you start improvising."
              right={<Pill text="Now" tone="accent" />}
              accent
            >
              <div className="text-lg font-semibold text-black">{effectiveNextAction.title}</div>
              <div className="mt-2 text-sm leading-relaxed text-gray-700">
                {effectiveNextAction.description}
              </div>

              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                <PrimaryButton href={effectiveNextAction.primaryHref}>{effectiveNextAction.primaryLabel}</PrimaryButton>
                <SecondaryButton href={effectiveNextAction.secondaryHref}>{effectiveNextAction.secondaryLabel}</SecondaryButton>
              </div>
            </Card>

            <Card title="Context snapshot" subtitle="Supporting facts behind the recommendation." accent>
              <div className="grid gap-4 sm:grid-cols-2">
                <StatBox
                  label="Review due"
                  value={String(activeDueReviewCount)}
                  hint="Recovery pressure"
                  accent={activeDueReviewCount > 0}
                />
                <StatBox
                  label="Exam countdown"
                  value={
                    dleft === null
                      ? "Unset"
                      : dleft < 0
                      ? "Passed"
                      : dleft === 0
                      ? "Today"
                      : `${dleft}d`
                  }
                  hint="Based on profile date"
                />
                <StatBox
                  label="Stable weak areas"
                  value={String(stableWeakAreas.length)}
                  hint="At least 6 attempts"
                  accent={stableWeakAreas.length > 0}
                />
                <StatBox
                  label="Low-signal rows"
                  value={String(lowSignalCount)}
                  hint="Needs more evidence"
                />
              </div>

              {myLeague && (
                <div className="mt-4 rounded-2xl border border-gray-200 bg-white p-4 text-sm text-gray-700">
                  League snapshot: rank #{myLeague.rank} with {myLeague.points} weekly points.
                </div>
              )}
            </Card>
          </div>

          <Card
            title="Your 3-step route"
            subtitle="Do not try to fix everything at once. Follow a sequence."
            right={<Pill text="Action plan" tone="accent" />}
          >
            <div className="grid gap-3">
              {threeStepPlan.map((item) => (
                <div key={item.step} className="rounded-2xl border border-gray-200 bg-white p-5">
                  <div className="flex items-start gap-4">
                    <div className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-[#c7dbff] bg-[#eef4ff] text-sm font-semibold text-[#004aad]">
                      {item.step}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="text-base font-semibold text-black">{item.title}</div>
                      <div className="mt-2 text-sm leading-relaxed text-gray-700">{item.text}</div>

                      <div className="mt-4 max-w-xs">
                        <PrimaryButton href={item.href}>{item.label}</PrimaryButton>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <div className="grid gap-4 lg:grid-cols-2">
            <Card title="Strongest current concerns" subtitle="These are the weakest stable signals, not random low-sample noise.">
              {stableWeakAreas.length > 0 ? (
                <div className="grid gap-3">
                  {stableWeakAreas.map((row, i) => (
                    <div key={`${row.subskill}-${i}`} className="rounded-xl border border-gray-200 p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <div className="font-semibold text-black">{row.subskill}</div>
                          <div className="mt-1 text-xs text-gray-600">
                            {row.domain} • {row.skill}
                          </div>
                          <div className="mt-2 text-sm text-gray-700">
                            {pct(row.accuracy)}% over {row.attempts} attempts • {confidenceLabel(row.attempts)} confidence
                          </div>
                        </div>

                        <Link
                          href={`/practice?subject=${skillsReading.includes(row) ? "Reading" : "Math"}&subskill=${encodeURIComponent(row.subskill)}`}
                          className="text-sm font-semibold text-[#004aad] underline hover:text-[#003b88]"
                        >
                          Repair
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-sm text-gray-700">
                  No stable weak zones yet. Generate more evidence before trying to over-interpret the map.
                </div>
              )}
            </Card>

            <Card title="AI guardrails" subtitle="Keep the coach useful, grounded, and cheap.">
              <div className="text-sm leading-relaxed text-gray-700">
                This page is driven by deterministic performance logic first. AI should only explain the signals already present:
                due review, weak zones, sample size, and the next action.
              </div>

              <div className="mt-4 rounded-xl border border-[#d9e7ff] bg-[#f8fbff] p-4 text-sm text-gray-700">
                Guardrail: no score promises, no generic motivation, no broad chat. The output should make the next session clearer.
              </div>
              <div className="mt-4 rounded-xl border border-gray-200 bg-white p-4 text-sm text-gray-700">
                Current plan: <span className="font-semibold text-black">{tier.label}</span>
                <span className="mx-2 text-gray-300">•</span>
                Coach AI:{" "}
                <span className="font-semibold text-black">
                  {tier.limits.coachAi ? `${tier.limits.coachRateLimitPer10Min} requests / 10m` : "Locked"}
                </span>
              </div>

              <div className="mt-5 grid gap-3 sm:grid-cols-2">
                <SecondaryButton href="/today">Back to Today</SecondaryButton>
                <SecondaryButton href="/skills">Open Skills</SecondaryButton>
              </div>
            </Card>
          </div>
        </div>
      )}
      {!loading && !err && (
        <ActionDock
          title="Strategist command"
          note={effectiveNextAction.description}
          primary={{ label: effectiveNextAction.primaryLabel, href: effectiveNextAction.primaryHref }}
          secondary={{ label: effectiveNextAction.secondaryLabel, href: effectiveNextAction.secondaryHref }}
        />
      )}
    </main>
  );
}
